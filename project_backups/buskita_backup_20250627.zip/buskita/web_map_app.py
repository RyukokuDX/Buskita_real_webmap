import requests
from flask import Flask, jsonify, render_template
from datetime import datetime
import json
import os

app = Flask(__name__)

# buskita.com APIのベースURL
API_BASE_URL = "https://api.buskita.com"
# 滋賀帝産バスのサイトID
SITE_ID = 9
# 取得したバス情報を保存するバックアップファイルのパス
BACKUP_FILE = 'buskita/last_known_buses.json'

def filter_and_format_buses(bus_list):
    """
    バスのリストを受け取り、位置情報があるものだけを抽出・整形する
    """
    locations = []
    if not bus_list:
        return locations
        
    for bus in bus_list:
        if bus and 'position' in bus and 'latitude' in bus['position'] and 'longitude' in bus['position']:
            try:
                locations.append({
                    'id': bus.get('workNo'),
                    'lat': float(bus['position']['latitude']),
                    'lng': float(bus['position']['longitude']),
                    'name': bus.get('r_name'),
                    'speed': bus.get('speed'),
                    'updated_at': bus.get('updateTime')
                })
            except (ValueError, TypeError):
                # 型変換に失敗した場合は、そのバスをスキップ
                continue
    return locations

def get_live_bus_data():
    """
    get-buses APIを叩いて、運行中の全バスの位置情報を取得する
    成功した場合、バックアップファイルに保存する
    """
    endpoint = f"{API_BASE_URL}/get-buses"
    payload = {
        "language": 1,
        "siteId": SITE_ID
    }
    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15'
    }

    try:
        response = requests.post(endpoint, json=payload, headers=headers, timeout=10)
        response.raise_for_status()
        data = response.json()
        buses_raw = data.get('buses', [])
        
        # 取得に成功し、バスが1台以上いればバックアップを保存
        if len(buses_raw) > 0:
            with open(BACKUP_FILE, 'w', encoding='utf-8') as f:
                json.dump(buses_raw, f, ensure_ascii=False, indent=2)
        
        # 整形したデータを返す
        return filter_and_format_buses(buses_raw)
        
    except requests.exceptions.RequestException as e:
        print(f"APIリクエストエラー: {e}")
        return None # エラー時はNoneを返す

@app.route('/')
def index():
    """
    マップを表示するメインページ
    """
    return render_template('index.html')

@app.route('/api/bus_locations')
def api_bus_locations():
    """
    バスの位置情報をJSONで返すAPIエンドポイント
    取得に失敗した場合はバックアップを返す
    """
    locations = get_live_bus_data()
    
    is_stale = False
    
    if locations is None or len(locations) == 0:
        print(f"[{datetime.now()}] APIから有効なデータが取得できませんでした。バックアップを試みます。")
        if os.path.exists(BACKUP_FILE):
            try:
                with open(BACKUP_FILE, 'r', encoding='utf-8') as f:
                    buses_raw_from_backup = json.load(f)
                
                # バックアップデータもフィルタリングする
                locations = filter_and_format_buses(buses_raw_from_backup)
                is_stale = True
                print(f"[{datetime.now()}] バックアップファイルを使用しました。 (有効なバス {len(locations)}台)")
            except (json.JSONDecodeError, IOError) as e:
                print(f"バックアップファイルの読み込みに失敗しました: {e}")
                locations = []
        else:
            locations = []
    else:
        print(f"[{datetime.now()}] APIから {len(locations)} 台の有効なバス情報を取得しました。")

    
    return jsonify({
        'buses': locations,
        'is_stale': is_stale
    })

if __name__ == '__main__':
    # Flaskアプリをデバッグモードで実行
    # host='0.0.0.0' を指定して、外部からのアクセスを許可する
    app.run(debug=True, host='0.0.0.0', port=5001) 